import networkx as nx

from database.DAO import DAO
from model.operatore import Operatore
from model.fascicolo import Fascicolo


class Model:
    def __init__(self):
        self._grafo = nx.Graph()

    def get_sedi(self) -> list[str]:
        return DAO.get_sedi()

    def create_graph(self, sede: str):
        self._grafo.clear()

        operatori = DAO.get_nodes_operatori(sede)
        fascicoli = DAO.get_nodes_fascicoli(sede)

        # aggiunta nodi con attributo bipartite
        for op in operatori:
            self._grafo.add_node(op, bipartite=0)
        for fasc in fascicoli:
            self._grafo.add_node(fasc, bipartite=1)

        # dizionari per lookup rapido id -> oggetto
        map_op = {op.id: op for op in operatori}
        map_fasc = {fasc.id: fasc for fasc in fascicoli}

        # calcolo degli edges
        edges = DAO.get_edges(sede)
        for id_op, id_fasc, tot_pagine in edges:
            if id_op in map_op and id_fasc in map_fasc:
                self._grafo.add_edge(map_op[id_op], map_fasc[id_fasc], weight=tot_pagine)

    def get_num_of_nodes(self) -> int:
        return self._grafo.number_of_nodes()

    def get_num_of_edges(self) -> int:
        return self._grafo.number_of_edges()

    def get_nodes_operatori(self) -> list[Operatore]:
        return [n for n, d in self._grafo.nodes(data=True) if d.get("bipartite") == 0]

    def get_nodes_fascicoli(self) -> list[Fascicolo]:
        return [n for n, d in self._grafo.nodes(data=True) if d.get("bipartite") == 1]

    def get_top5_operatori(self) -> list[tuple]:
        """I 5 operatori con più pagine totali inserite."""
        result = []
        for op in self.get_nodes_operatori():
            tot = sum(d["weight"] for _, _, d in self._grafo.edges(op, data=True))
            result.append((op, tot))
        result.sort(key=lambda x: x[1], reverse=True)
        return result[0:5]

    def get_top5_fascicoli(self) -> list[tuple]:
        """I 5 fascicoli con più pagine totali lavorate."""
        result = []
        for fasc in self.get_nodes_fascicoli():
            tot = sum(d["weight"] for _, _, d in self._grafo.edges(fasc, data=True))
            result.append((fasc, tot))
        result.sort(key=lambda x: x[1], reverse=True)
        return result[0:5]

    def get_top5_archi(self) -> list[tuple]:
        """I 5 archi con peso maggiore (operatore più produttivo su singolo fascicolo)."""
        edges = [e for e in self._grafo.edges(data=True)]
        edges.sort(key=lambda x: x[2]["weight"], reverse=True)
        return edges[0:5]
