import flet as ft


class View(ft.UserControl):
    def __init__(self, page: ft.Page):
        super().__init__()
        # page stuff
        self._page = page
        self._page.title = "Digitalizzazione - Grafo Bipartito"
        self._page.horizontal_alignment = "CENTER"
        self._page.window_width = 950
        self._page.window_height = 800
        self._page.theme_mode = ft.ThemeMode.LIGHT
        # controller
        self._controller = None
        # title
        self._title = None
        # controls
        self.dd_sede: ft.Dropdown = None
        self.btn_graph = None
        self.btn_stats = None
        # output
        self.txt_result1 = None
        self.txt_result2 = None

    def load_interface(self):
        # title
        self._title = ft.Text("Digitalizzazione - Grafo Bipartito Operatori/Fascicoli",
                              color="blue", size=20)
        self._page.controls.append(self._title)

        # prima riga: selezione sede
        self.dd_sede = ft.Dropdown(label="Sede",
                                   hint_text="Seleziona una sede")
        self._controller.fill_dd_sede()

        row1 = ft.Row([self.dd_sede],
                      alignment=ft.MainAxisAlignment.SPACE_EVENLY)
        self._page.controls.append(row1)

        # seconda riga: bottoni
        self.btn_graph = ft.ElevatedButton(text="Crea Grafo",
                                           tooltip="Crea il grafo bipartito per la sede selezionata",
                                           on_click=self._controller.handle_graph)
        self.btn_stats = ft.ElevatedButton(text="Calcola Statistiche",
                                           tooltip="Mostra top 5 operatori, fascicoli e archi",
                                           on_click=self._controller.handle_stats)
        self.btn_stats.disabled = True

        row2 = ft.Row([self.btn_graph, self.btn_stats],
                      alignment=ft.MainAxisAlignment.SPACE_EVENLY)
        self._page.controls.append(row2)

        # aree di output
        self.txt_result1 = ft.ListView(width=400, expand=1, spacing=10,
                                       padding=20, auto_scroll=False)
        self.txt_result2 = ft.ListView(width=400, expand=1, spacing=10,
                                       padding=20, auto_scroll=False)
        self.txt_result1.controls.append(ft.Text("Risultati grafo"))
        self.txt_result2.controls.append(ft.Text("Statistiche"))

        container1 = ft.Container(
            content=self.txt_result1,
            margin=10,
            padding=10,
            alignment=ft.alignment.center,
            bgcolor=ft.colors.GREY_200,
            width=450,
            height=550,
            border_radius=10,
        )
        container2 = ft.Container(
            content=self.txt_result2,
            margin=10,
            padding=10,
            alignment=ft.alignment.center,
            bgcolor=ft.colors.GREY_200,
            width=450,
            height=550,
            border_radius=10,
        )

        row3 = ft.Row([container1, container2],
                      alignment=ft.MainAxisAlignment.SPACE_EVENLY,
                      spacing=50)
        self._page.controls.append(row3)
        self._page.update()

    @property
    def controller(self):
        return self._controller

    @controller.setter
    def controller(self, controller):
        self._controller = controller

    def set_controller(self, controller):
        self._controller = controller

    def create_alert(self, message):
        dlg = ft.AlertDialog(title=ft.Text(message))
        self._page.dialog = dlg
        dlg.open = True
        self._page.update()

    def update_page(self):
        self._page.update()
