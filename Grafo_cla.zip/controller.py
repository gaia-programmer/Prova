import flet as ft
from UI.view import View
from model.modello import Model


class Controller:
    def __init__(self, view: View, model: Model):
        # the view, with the graphical elements of the UI
        self._view: View = view
        # the model, which implements the logic of the program and holds the data
        self._model: Model = model

    def fill_dd_sede(self):
        sedi = self._model.get_sedi()
        self._view.dd_sede.options.clear()
        for s in sedi:
            self._view.dd_sede.options.append(ft.dropdown.Option(f"{s}"))

    def handle_graph(self, e):
        # leggo la sede selezionata
        if self._view.dd_sede.value is None or self._view.dd_sede.value == "":
            self._view.create_alert("Selezionare una sede!")
            return
        sede = self._view.dd_sede.value

        # creo il grafo
        self._view.txt_result1.controls.clear()
        self._model.create_graph(sede)

        self._view.txt_result1.controls.append(
            ft.Text(f"Grafo creato per: {sede}", weight=ft.FontWeight.BOLD))
        self._view.txt_result1.controls.append(
            ft.Text(f"Numero di vertici: {self._model.get_num_of_nodes()}"))
        self._view.txt_result1.controls.append(
            ft.Text(f"  di cui operatori: {len(self._model.get_nodes_operatori())}"))
        self._view.txt_result1.controls.append(
            ft.Text(f"  di cui fascicoli: {len(self._model.get_nodes_fascicoli())}"))
        self._view.txt_result1.controls.append(
            ft.Text(f"Numero di archi   : {self._model.get_num_of_edges()}"))

        self._view.btn_stats.disabled = False
        self._view.update_page()

    def handle_stats(self, e):
        self._view.txt_result2.controls.clear()

        # top 5 operatori
        self._view.txt_result2.controls.append(
            ft.Text("Top 5 operatori per pagine inserite:", weight=ft.FontWeight.BOLD))
        for op, tot in self._model.get_top5_operatori():
            self._view.txt_result2.controls.append(
                ft.Text(f"  {op}  ->  {tot} pag."))

        # top 5 fascicoli
        self._view.txt_result2.controls.append(ft.Text(""))
        self._view.txt_result2.controls.append(
            ft.Text("Top 5 fascicoli più lavorati:", weight=ft.FontWeight.BOLD))
        for fasc, tot in self._model.get_top5_fascicoli():
            self._view.txt_result2.controls.append(
                ft.Text(f"  {fasc}  ->  {tot} pag."))

        # top 5 archi
        self._view.txt_result2.controls.append(ft.Text(""))
        self._view.txt_result2.controls.append(
            ft.Text("Top 5 archi (operatore su singolo fascicolo):", weight=ft.FontWeight.BOLD))
        for u, v, data in self._model.get_top5_archi():
            self._view.txt_result2.controls.append(
                ft.Text(f"  {u} <-> {v}  |  peso = {data['weight']}"))

        self._view.update_page()
