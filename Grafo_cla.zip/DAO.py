from database.DB_connect import DBConnect
from model.operatore import Operatore
from model.fascicolo import Fascicolo


class DAO:
    def __init__(self):
        pass

    @staticmethod
    def get_sedi() -> list[str]:
        cnx = DBConnect.get_connection()
        result = []
        if cnx is None:
            print("Connessione fallita")
        else:
            cursor = cnx.cursor(dictionary=True)
            query = """SELECT DISTINCT sede
                       FROM attivita
                       ORDER BY sede ASC"""
            cursor.execute(query)

            for row in cursor:
                result.append(row["sede"])

            cursor.close()
            cnx.close()
        return result

    @staticmethod
    def get_nodes_operatori(sede: str) -> list[Operatore]:
        cnx = DBConnect.get_connection()
        result = []
        if cnx is None:
            print("Connessione fallita")
        else:
            cursor = cnx.cursor(dictionary=True)
            query = """SELECT DISTINCT id_operatore, nome_operatore, sede, ufficio
                       FROM attivita
                       WHERE sede = %s"""
            cursor.execute(query, (sede,))

            for row in cursor:
                result.append(Operatore(
                    id=row["id_operatore"],
                    nome=row["nome_operatore"],
                    sede=row["sede"],
                    ufficio=row["ufficio"]
                ))

            cursor.close()
            cnx.close()
        return result

    @staticmethod
    def get_nodes_fascicoli(sede: str) -> list[Fascicolo]:
        cnx = DBConnect.get_connection()
        result = []
        if cnx is None:
            print("Connessione fallita")
        else:
            cursor = cnx.cursor(dictionary=True)
            query = """SELECT DISTINCT id_fascicolo, anno_fascicolo, ufficio
                       FROM attivita
                       WHERE sede = %s"""
            cursor.execute(query, (sede,))

            for row in cursor:
                result.append(Fascicolo(
                    id=row["id_fascicolo"],
                    anno=row["anno_fascicolo"],
                    ufficio=row["ufficio"]
                ))

            cursor.close()
            cnx.close()
        return result

    @staticmethod
    def get_edges(sede: str) -> list[tuple]:
        """Restituisce lista di (id_operatore, id_fascicolo, tot_pagine)
        considerando solo gli inserimenti (Inserimento_Pagina)."""
        cnx = DBConnect.get_connection()
        result = []
        if cnx is None:
            print("Connessione fallita")
        else:
            cursor = cnx.cursor(dictionary=True)
            query = """SELECT id_operatore, id_fascicolo,
                              SUM(conta_pagine_giorno) AS tot_pagine
                       FROM attivita
                       WHERE sede = %s
                         AND attivita = 'Inserimento_Pagina'
                       GROUP BY id_operatore, id_fascicolo"""
            cursor.execute(query, (sede,))

            for row in cursor:
                result.append((row["id_operatore"], row["id_fascicolo"], row["tot_pagine"]))

            cursor.close()
            cnx.close()
        return result
